package DAO;

import Model.EmployeeBean;
import Model.TicketBean;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Vector;
import org.apache.catalina.User;

public class DatabaseManager {

    public static Connection getConnection() throws Exception {  
         Connection con;
        Class.forName("com.mysql.jdbc.Driver");
        con = DriverManager.getConnection("jdbc:mysql://localhost:3306/service","root","root");
        System.out.println("Connection Successful " + con);
        return con;
    }
    public static List<EmployeeBean> getAllEmployees() throws Exception {
 		String query="select * from employees";
                System.out.println(query);
		Statement st=null;
		ResultSet result=null;
                EmployeeBean bean=null;
                List<EmployeeBean> list = new ArrayList<EmployeeBean>();
		try{
			st=getConnection().createStatement();
			result=st.executeQuery(query);
			
			while(result.next()){
				bean=new EmployeeBean();	
				bean.setEmployeeId(result.getInt("employeeId") );
				bean.setFirstName(result.getString("firstName") );
				bean.setLastName(result.getString("lastName") );
                                bean.setService(result.getString("service"));
                                bean.setBild(result.getString("bild"));
                                list.add(bean);
			}
			return list;
		}finally{
			if(result!=null)result.close();
			if(st!=null)st.close();
		} 
    }     
      
	public static int insertTicket(TicketBean bean)throws Exception{
		String query="INSERT into ticket (employeeId,firstName,lastName,date,email,paymentId) values ("+bean.getEmployeeId()+",'"+bean.getFirstName()+"','"+bean.getLastName()+"','"+bean.getDate()+"',"+bean.getEmail()+","+bean.getPaymentMethod()+") ";
		System.out.println(query);
		
		Statement st=null;
		try{
			st=getConnection().createStatement();
			int rows=st.executeUpdate(query);
			return rows;
		}finally{
			if (st!=null)
			st.close();
		}
	}         

}

