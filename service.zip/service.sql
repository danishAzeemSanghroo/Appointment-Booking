/*
SQLyog Community v13.1.6 (64 bit)
MySQL - 5.7.30-log : Database - service
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`service` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `service`;

/*Table structure for table `employees` */

DROP TABLE IF EXISTS `employees`;

CREATE TABLE `employees` (
  `employeeId` int(11) NOT NULL AUTO_INCREMENT,
  `firstName` varchar(255) DEFAULT NULL,
  `lastName` varchar(255) DEFAULT NULL,
  `service` varchar(255) DEFAULT NULL,
  `bild` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`employeeId`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

/*Data for the table `employees` */

insert  into `employees`(`employeeId`,`firstName`,`lastName`,`service`,`bild`) values 
(1,'Hellen ','Miller','Smart Cook','cook.jpg'),
(2,'Kite','Night','Smart engineer','engineer.jpg'),
(3,'Alien','Nope','Smart decision','decision.jpg'),
(4,'Resh','Kina','Smart port','port.jpg');

/*Table structure for table `payment` */

DROP TABLE IF EXISTS `payment`;

CREATE TABLE `payment` (
  `paymentId` int(11) NOT NULL AUTO_INCREMENT,
  `paymentMethod` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`paymentId`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

/*Data for the table `payment` */

insert  into `payment`(`paymentId`,`paymentMethod`) values 
(1,'PAYPAL'),
(2,'RECHNUNG'),
(3,'CREDIT CARD');

/*Table structure for table `ticket` */

DROP TABLE IF EXISTS `ticket`;

CREATE TABLE `ticket` (
  `ticketId` int(11) NOT NULL AUTO_INCREMENT,
  `employeeId` int(11) NOT NULL,
  `firstName` varchar(255) DEFAULT NULL,
  `lastName` varchar(255) DEFAULT NULL,
  `date` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `paymentId` int(11) NOT NULL,
  PRIMARY KEY (`ticketId`),
  KEY `employeeId` (`employeeId`),
  KEY `paymentId` (`paymentId`),
  CONSTRAINT `ticket_ibfk_1` FOREIGN KEY (`employeeId`) REFERENCES `employees` (`employeeId`),
  CONSTRAINT `ticket_ibfk_2` FOREIGN KEY (`paymentId`) REFERENCES `payment` (`paymentId`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

/*Data for the table `ticket` */

insert  into `ticket`(`ticketId`,`employeeId`,`firstName`,`lastName`,`date`,`email`,`paymentId`) values 
(1,1,'Akas','Nak','02-02-2020','akas@gmail.com',1),
(2,3,'Kity','pere','29-03-2023','-1997',1);

/*Table structure for table `venue` */

DROP TABLE IF EXISTS `venue`;

CREATE TABLE `venue` (
  `venueId` int(11) NOT NULL AUTO_INCREMENT,
  `venueName` varchar(255) DEFAULT NULL,
  `hour` int(11) DEFAULT NULL,
  `ort` varchar(255) DEFAULT NULL,
  `plz` int(11) DEFAULT NULL,
  PRIMARY KEY (`venueId`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `venue` */

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
