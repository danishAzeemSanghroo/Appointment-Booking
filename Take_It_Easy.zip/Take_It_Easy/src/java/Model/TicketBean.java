
package Model;


public class TicketBean {
    
    private int ticketId;
    private String firstName;
    private String lastName;
    private String date;
    private String email;
    private int employeeId;
    private int paymentMethod; 

    public TicketBean(int ticketId, String firstName, String lastName, String date, String email, int employeeId, int paymentMethod) {
        this.ticketId = ticketId;
        this.firstName = firstName;
        this.lastName = lastName;
        this.date = date;
        this.email = email;
        this.employeeId = employeeId;
        this.paymentMethod = paymentMethod;
    }

    public TicketBean() {
    }

    public int getTicketId() {
        return ticketId;
    }

    public void setTicketId(int ticketId) {
        this.ticketId = ticketId;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public int getEmployeeId() {
        return employeeId;
    }

    public void setEmployeeId(int employeeId) {
        this.employeeId = employeeId;
    }

    public int getPaymentMethod() {
        return paymentMethod;
    }

    public void setPaymentMethod(int paymentMethod) {
        this.paymentMethod = paymentMethod;
    }
    
    
    
}
