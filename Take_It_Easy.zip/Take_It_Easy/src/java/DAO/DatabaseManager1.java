
package DAO;





import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Vector;

public class DatabaseManager1 {

    
    // private static String fac_id;
    private static final String url = "jdbc:postgresql://localhost:5433/Service";
    private final String user = "root";
    private final String password = "root";
   

    public static Connection getConnection() throws Exception {  
         Connection con;
        	
        Class.forName("org.postgresql.Driver");
        con = DriverManager.getConnection("jdbc:postgresql://localhost:5432/Service","postgres","root");
        System.out.println("Connection Successful " + con);
        return con;
    }
        public static void main(String[] args) throws Exception {
        getConnection();
    }
}
